"""
Your module description
"""
Myvalue=1
print(Myvalue)
print(type(Myvalue))
print(str(Myvalue) + " is of the data type " + str(type(Myvalue)))

myValue=3.14
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

myValue=5j
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))

myValue=True
print(myValue)
print(type(myValue))
print

myValue=False
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))